#include <iostream>
#include <cstring>
#include <cstdlib>
#include <sstream> 
#include "Bag.h"
using namespace std;

Bag::Bag()
// pre: Nenhuma
// pos: A sacola eh criada vazia (sem elementos)
{ used = 0;
}

void Bag::insert(int newEntry)
// pre: Bag n�o esteja cheia
// pos: Uma nova c�pia de NewEntry eh adicionada aa Bag 
{ if(full())
  { cout << "Sacola cheia..." << endl;
    abort();
  }
  used++;
  data[used] = newEntry;
}

int Bag::occurrence(int entry)
// pre: Nenhuma
// pos: Retorna o numero de ocorrencias do elemento
//      Entry na Bag
{ int i,total=0;

  for(i=1; i<=used; i++)
    if(data[i] == entry)
      total++;
  return total;  
}

void Bag::remove(int entry)
// pre: Nenhuma
// pos: Remove uma ocorrencia do elemento Entry na Bag.
//      Se o elemento nao existir, a Bag permanece inalterada.

{ // sua implementacao vem aqui...
}

bool Bag::full()
// pre: Nenhuma
// pos: Retorna true se a sacola estah cheia; false caso contrario
{ return (used == CAPACITY);
}

int Bag::size()
// pre: Nenhuma
// pos: Retorna o numero de elementos na sacola
{ return used;
}

string Bag::toString()
// pre: Nenhuma
// pos: Retorna Bag no formato de string
//      Por exemplo, Bag contendo elementos 8,10,8
//      retorna [8,10,8]
{ int i;
  stringstream ss;

  ss << "[";
  for(i = 1; i <= used; i++)
  {  ss << data[i];
     if( i != used )
       ss << ",";
  }
  ss << "]";
  return ss.str();
}

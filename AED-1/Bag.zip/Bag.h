// Bag.h
// Declara��o/interface para sacola
#include <cstring>
using namespace std;

#ifndef BAG_H
#define BAG_H

class Bag
{ public:
     Bag();
     void insert(int NewEntry);
     int occurrence(int Entry);
     void remove(int Entry);
     bool full();
     int size();
     string toString();
  private:
    static const int CAPACITY = 100;
    int data[CAPACITY+1];
    int used;
};

#endif


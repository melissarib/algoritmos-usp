//LEONARDO DO NASCIMENTO - 7695815
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <sstream>
#include "ListTemplate.h"
using namespace std;

#ifndef TOPSORT_H
#define TOPSORT_H

typedef int TaskType;  // tipo de tarefa

class TopSort
{ public:
    TopSort(string projectName = "Unnamed project");
    ~TopSort();
    int GetNodes();
    int GetEdges();
    string GetProjectName();
    void Clear();
    void AddRelation(TaskType x, TaskType y);
    List<TaskType> FindTopSort();
    string toString();

  private:
    // definicao de tipos
    struct leader;   // declaracoes incompletas, pois leader e trailer sao dependentes entre si
    struct trailer;  // declaracoes completas mais abaixo no codigo
 
    typedef leader  * leaderPointer;
    typedef trailer * trailerPointer;

    struct leader
    { TaskType task;          
      int      predecessors;       // numero de precedessores da tarefa task
      leaderPointer  nextLeader;
      trailerPointer nextTrailer;
    };

    struct trailer
    { leaderPointer  nextLeader;
      trailerPointer nextTrailer;
    };

    // definicao de campos do objeto
    leaderPointer head, sentinel; // inicio e final da estrutura de dados   
    leaderPointer start;          // ponteiro para a tarefa sem predecessores
    string projectName;           // nome do projeto (grafo)
    int nodes;                    // numero de elementos no grafo
    int edges;                    // numero de arestas no grafo

    // definicao de metodos privados
    leaderPointer InsertNode(TaskType task);
    void InsertEdge(leaderPointer &p, leaderPointer &q);
    void LinkNoPreambulos();        // interliga os elementos que o registro indica zero predecessores
    void NodeClear(leaderPointer &node);// apaga um no
    void PrintList(); //imprime estrutura
};

#endif /* TOPSORT_H */

//LEONARDO DO NASCIMENTO - 7695815
#include "TopSort.h"
using namespace std;

//------------------------------------------------------------------------------------------------------------
// pre: nenhum
// pos: inicializa campos do objeto representando nenhum noh e nenhuma aresta; cria sentinela
TopSort::TopSort(string projectName)
{ sentinel = new leader;
  sentinel->predecessors = 1;
  head = sentinel;
  start = NULL; //cabeca da ordenacao parcial
  nodes = edges = 0;
  this->projectName = projectName;
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: libera espaco ocupado pelos elementos, incluindo sentinela
TopSort::~TopSort()
{ Clear();
  delete sentinel;
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: retorna o numero de nohs no grafo
int TopSort::GetNodes()
{ return nodes;
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: retorna o numero de arestas no grafo
int TopSort::GetEdges()
{ return edges;
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: retorna o nome do projeto
string TopSort::GetProjectName()
{ return projectName;
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: libera espaco ocupados pelos elementos e torna a estrutura vazia, pronta para ser reutilizada;
//      projectName contem "Unnamed project"
void TopSort::Clear()
{ projectName = "Unnamed project";
  //condição que o diagrama esta vazio
  if(head == sentinel && start == NULL)
  {
    return;
  } 

  else
  { 
    leaderPointer l;
    trailerPointer del;

    //apaga lista sem ciclos
    l=start;
    while(l != NULL)
    {
      del = l->nextTrailer;
      while(l->nextTrailer != NULL)
      {
        l->nextTrailer = del->nextTrailer;
        delete del;
        del = l->nextTrailer;
        edges--;
      }
      start = start->nextLeader;
      delete l;
      l = start;
      nodes--;
    }

    //apaga ciclos
    l = head;
    while(l!=sentinel)
    {
      del = l->nextTrailer;
      while(l->nextTrailer != NULL)
      {
        l->nextTrailer = del->nextTrailer;
        delete del;
        del = l->nextTrailer;
        edges--;
      }
      l = l->nextLeader;
      delete head;
      head = l;
      nodes--;
    }
    return;
  }
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: adiciona nohs x e y como tambem aresta x < y na estrutura
void TopSort::AddRelation(TaskType x, TaskType y)
{ leaderPointer p,q;

  p = InsertNode(x);
  q = InsertNode(y);
  InsertEdge(p,q);              
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: retorna ordem topologia em uma lista (se tamanho da lista for igual ao numero de nohs no diagrama)
List<TaskType> TopSort::FindTopSort()
{   

  LinkNoPreambulos();

  List<TaskType> L;
  leaderPointer q;
  trailerPointer t;

  q = start;
  while (q != NULL) //varre leader     
  { 
    // efetuar a saída deste elemento, depois eliminá-lo
    L.Insert(L.Size()+1,q->task);       //colocar q->task no fim da lista de saída L

    t = q->nextTrailer;//t aponta para o primeiro trailer
    while(t != NULL)//varre trailer
    {//decrementar o contador do predecessor de todos os nos apontados pelos trailers de t.
      (t->nextLeader)->predecessors--;
            
      if((t->nextLeader)->predecessors == 0)
      {//se algum contador se tornar 0, inserir este elemento na lista q de preâmbulos.
        
        // inserir na segunda posicao.
        sentinel->task = (t->nextLeader)->task;
        leaderPointer aux;
        aux = head;
        if (aux->task == sentinel->task)//primeiro elemento mudara para a lista sem preambulos.
        {
          head = head->nextLeader;
        }
        else
        {
          while((aux->nextLeader)->task != sentinel->task)//procura elemento
            aux = aux->nextLeader;
          aux->nextLeader = aux->nextLeader->nextLeader;//religa a estrutura
        }
        aux = q->nextLeader;
        q->nextLeader = t->nextLeader;        
        (t->nextLeader)->nextLeader = aux;
      }
      t = t->nextTrailer;
    }
    q = q->nextLeader;
  }
	return L;//List<TaskType>
}
//------------------------------------------------------------------------------------------------------------
// pre: objecto criado, contendo sentinela
// pos: realiza busca com insercao da tarefa task; retorna um ponteiro para o noh onde se encontra task
TopSort::leaderPointer TopSort::InsertNode(TaskType task)
{ sentinel->task = task;//insercao do elemento sentinela.

  if(head->task == task)
  {//O diagrama esta vazio ou task eh a primeira tarefa.
    if(nodes > 0)
    {//quando task eh a primeira tarefa.
      return head;
    }
    else
    {//quando o diagrama esta vazio.
      leaderPointer lp = new leader;
      lp->task = task;
      lp->predecessors = 0;
      lp->nextLeader = sentinel;
      lp->nextTrailer = NULL;
      head = lp;
      nodes++;
      return lp;
    }
  }
  
  //busca com sentinela de task.
  leaderPointer lp = head;
  while( (lp->nextLeader)->task != task)
  {
    lp = lp->nextLeader;
  }
  if(lp->nextLeader != sentinel)
  { //elemento ja faz parte do diagrama.
    return lp->nextLeader; 
  }
  else if(lp->nextLeader == sentinel)
  {//elemento nao faz parte do diagrama.
    leaderPointer e = new leader;
    e->task = task;
    e->predecessors = 0;
    e->nextLeader = sentinel;
    e->nextTrailer = NULL;
    lp->nextLeader = e;
    nodes++;
    return e;
  }
}
//------------------------------------------------------------------------------------------------------------
// pre: no's p e q jah estao inseridos na estrutura de dados 
// pos: insere aresta p < q
void TopSort::InsertEdge(leaderPointer &p, leaderPointer &q)
{ trailerPointer t;
  
  if(p->nextTrailer == NULL)
  {//tarefa não tem postambulo
    t = new trailer;
    t->nextLeader = q; //aresta
    t->nextTrailer = NULL;
    p->nextTrailer = t;
    q->predecessors++;
    edges++;
    return;
  }
  else
  { //teste se aresta ja existe
    for(t = p->nextTrailer;t != NULL;t = t->nextTrailer)
    {
      if(t->nextLeader == q)//aresta ja existe
      { return;
      }
    }
    
    //acrescenta um trailer na estrutura
    trailerPointer taux = p->nextTrailer;
    t = NULL;
    t = new trailer;
    p->nextTrailer = t;
    t->nextLeader = q;
    q->predecessors++;
    t->nextTrailer = taux;
    edges++;
    return;
  }
}
//------------------------------------------------------------------------------------------------------------
// pre: todos no's jah estao inseridos na estrutura de dados 
// pos: coleta e liga elementos sem predecessores.
void TopSort::LinkNoPreambulos()
{ leaderPointer p, q;
  // busca por preambulos sem predecessores
  p = head;
  while(p != sentinel)
  { //caso primeiro elemento tenha 0 predecessores
    if(p->predecessors == 0 && p==head)
    { q = p;
      p = p->nextLeader;
      q->nextLeader = start;
      start = q;
      head = p;
    }

    //caso elemento no meio da lista tenha 0 predecessores
    else
    {
      if (p->nextLeader!=sentinel && p->predecessors==0)
      {
        p = p->nextLeader;
        (q->nextLeader)->nextLeader = start;
        start = q->nextLeader;
        q->nextLeader = p;
      }

      //caso o ultimo elemento adicionado na lista tenha 0 predecessores
      else
      {
        if (p->nextLeader==sentinel && p->predecessors==0)
        {
        p = p->nextLeader;
        (q->nextLeader)->nextLeader = start;
        start = q->nextLeader;
        q->nextLeader = p;
        }
        else
        { //antes dos testes, p deve sempre apontar para o elemento a ser analizado e q apontar para o anterior.
          q = p;
          p = p->nextLeader;
        }
      }
    }
  }
}
//------------------------------------------------------------------------------------------------------------
// pre: no existir.
// pos: libera memoria do no.
void TopSort::NodeClear(leaderPointer &node)
{ 
  leaderPointer next;
  next = node->nextLeader;

  //remover trailer
  trailerPointer t = node->nextTrailer;
  while(t != NULL)
  {
    node->nextTrailer = t->nextTrailer;
    delete t;
    t = node->nextTrailer;
  }
  
  //removendo leader
  delete node;
  node = next;
}

//------------------------------------------------------------------------------------------------------------
// pre: lista ter elementos.
// pos: mostra campos task e predecessors da lista na tela.
void TopSort::PrintList()
{
  leaderPointer l;

  cout << endl << "\t\thead->\t";
  l=head;
  while(l!=sentinel)
  {
    cout << l->task << "--";
    l = l->nextLeader;
  }
  cout << "sentinel" << endl << "\t\t\t";
  l=head;
  while(l!=NULL)
  {
    cout << l->predecessors << "--";
    l = l->nextLeader;
  }
  
  cout << endl << endl << "\t\tstart->\t";
  l = start;
  while(l!=NULL)
  {
    cout << l->task << "--";
    l = l->nextLeader;
  }
  cout << endl << "\t\t\t";
  l = start;
  while(l!=NULL)
  {
    cout << l->predecessors << "--";
    l = l->nextLeader;
  }
  cout << endl << endl;
}

//---------------------------------------------------------------
string TopSort::toString()
{ leaderPointer l=head;
  string s;
  stringstream ss;
  ss << "\thead->\t";

  while (l!=sentinel)
  {  ss << l->task << ",";
     l = l->nextLeader;
  }
  ss << "sentinel";
  s = ss.str();
  return s.substr(0,s.length()-1);
}
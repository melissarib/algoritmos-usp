#include "Expression.h"
#include <math.h>
using namespace std;
//Felipe Lim�o Lopes de Almeida

// pre: nenhuma
// pos: Dada expressao infixa expression, converte-a na notacao posfixa expression encontra seu valor
Expression::Expression(string expression)
{  setInfix(expression);
}
                              
// pre: nenhuma
// pos: Dada expressao infixa s, converte-a na notacao posfixa e encontra seu valor
void Expression::setInfix(string expression)
{  infix = expression;
   infixToPostfix();
   evalPostfix();
}

// pre: objeto criado
// pos: retorna a expressao na notacao infixa
string Expression::getInfix()
{  return infix;
}

// pre: objeto criado
// pos: retorna a expressao na notacao posfixa (RPN)
string Expression::getPostfix()
{  return postfix;
}

// pre: objeto criado
// pos: retorna o valor da expressao na notacao posfixa (RPN)
int Expression::getValue()
{  return value;
}

//pre: nenhuma
//pos: retorna o valor equivalente do operando para comparar a precedencia
int precedente(char x){
	int a;
	switch(x){
		case '*':
			a = 2;break;
		case '/':
			a = 2;break;
		case '+':
			a = 1;break;
		case '-':
			a = 1;break;
		case '%': 
			a = 2;break;
		case '^':
			a = 4;break;
	}
	return a;
}

// pre: infix contem uma expressao aritmetica valida, contendo operadores e digitos na notacao infixa
// pos: postfix contem a mesma expressao dada por infix, convertida na notacao pos-fixada (RPN)
void Expression::infixToPostfix()
{ 
  postfix = "";
  Stack<char> pilha;
  int tamanho;
  char x, t;
  
  tamanho = infix.length();
  	
  for(int i=0;i<tamanho;i++){
	
  	x = getInfix().at(i);
  	if(x != ' '){
		if(isdigit(x)){ // Checa se o x � um digito
			postfix += x; // se for adicionar ao postfix
		}
		else if(x == '(') // checa se x � um parentese esquerdo
			pilha.push(x); // se for adiciona para a pilha
		else if(x == ')'){ // Checa se x � um parentese direito
			while(x != '(' && !pilha.empty()){ // enquanto x for diferente de um parentese esquerdo e a pilha nao for vazia
				pilha.pop(x); //tire o topo da pilha e guarde em x
				postfix += x; //adicione o x em postfix
				if(!pilha.empty()) //se a pilha nao for vazia
					pilha.getTop(x); //pegue o topo da pilha e coloque em x
			}
			if(x == '(' && !pilha.empty()) // se x for igual a parentese esquerdo e a pilha n�o � vazia
				pilha.pop(x); //tire o topo da pilha (que seria o parentese esquerdo)
		}
		else{
			if(pilha.empty()) //se a pilha for vazia t ser� vazio
				t = ' ';
			else
				pilha.getTop(t); //senao t ter� o valor do topo da pilha
			while(!pilha.empty() && t != '(' && precedente(x) <= precedente(t)){ //enquanto a pilha for diferente de vazio, t for diferente do parentese esquerdo e o valor da precedencia de x for menor ou igual a de t	
				pilha.pop(t); //tire o topo da pilha e guarde em t	
				postfix += t; //coloque t no postfix
				if(!pilha.empty()) //se a pilha nao for vazia 
					pilha.getTop(t); //pegue o topo e guarde em t
		}
			pilha.push(x); //coloque o valor de x na pilha que ser� ou um parentese esquerdo ou um operando
		}
		
	}
}
	while(!pilha.empty()){ //enquanto a pilha for vazia
		pilha.pop(x); //tire de x e coloque no postfix
		postfix += x;
	}
}

// pre: postfix contem a expressao na notacao posfixa
// pos: retorna o valor da expressao, utilzando Algoritmo 2
void Expression::evalPostfix()
{
  Stack<int> pilhaEval;
  int tamanho = postfix.length();
  char x;
  if(postfix.empty()) //se postfix for vazio adicione valor = 0
  	value = 0;
  else {
  	int valor1; // declara��o das variaveis equivalentes do valor 1 e 2
  	int valor2;
  	for(int i=0;i<tamanho;i++){ 
  		x = getPostfix().at(i);
  		if(isdigit(x)) //se postfix[i] for um n�mero
  			pilhaEval.push(x - '0'); //adicione a pilha o postfix[i] subtraindo por zero para transformar em int
  		else{
  				pilhaEval.pop(valor1); //senao tire dois valores da pilha e guarde no valor 1 e 2
  				pilhaEval.pop(valor2);
  			switch(x){ //fa�a a a��o correspondente para cada operando com os dois valores e adicione na pilha
  				case '*': pilhaEval.push(valor2*valor1);break;
  				case '/': pilhaEval.push(valor2/valor1);break;
  				case '+': pilhaEval.push(valor2+valor1);break;
  				case '-': pilhaEval.push(valor2-valor1);break;
				case '%': pilhaEval.push(valor2%valor1);break;
				case '^': pilhaEval.push(pow(valor2,valor1));break;
				default: break;
			  }
		  }  			
  	}
  	if(!pilhaEval.empty()) //Se a pilha nao estiver vazia pegue o topo da pilha para ser o value
  	pilhaEval.getTop(value);
  }
}

















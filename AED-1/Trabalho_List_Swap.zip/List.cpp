/*
 * List.cpp
 *
 *  Created on:
 *      Author:
 */
#include "List.h"
//Felipe Lim�o Lopes de Almeida

//pr�-condi��o: nenhuma 
//p�s-condi��o: Lista � criada e iniciada como vazia
List::List()
{
  head = NULL;
  count = 0;
}
//pr�-condi��o: Lista j� tenha sido criada 
//p�s-condi��o: Lista � finalizada (destru�da)
List::~List()
{
  clear();
}
//pr�-condi��o: Lista j� tenha sido criada 
//p�s-condi��o: fun��o retorna true se a Lista est� vazia
bool List::empty()
{
  return (head == NULL);
}
//pr�-condi��o: Lista j� tenha sido criada 
//p�s-condi��o: fun��o retorna true se a Lista est� cheia;
bool List::full()
{
   return false;
}
// pre-condicao: Lista ja tenha sido criada
// pos-condicao: Esvazia o conteudo da lista
void List::clear()
{ ListPointer q;

  while (head != NULL)
  {  q = head;
     head = head->nextNode;
     delete q;
  }
  count = 0;
}

// pre-condicao: Lista ja tenha sido criada
// pos-condicao: retorna o numero de elementos da lista
long List::size()
{
   return count;
}

// pre-condicao: Lista ja tenha sido criada e n�o est� cheia
// pos-condicao: Adiciona o item x na Lista na posi��o p e incrementa em 1 as posi��es de todas as entradas seguintes
void List::insert(long p, ListEntry x)
{ ListPointer newNode, current;

  if (p < 1 || p > count+1)
  { cout << "Posicao invalida" << endl;
    abort();
  }
  newNode = new ListNode;
  newNode->entry = x;
  if(p == 1)
  {  newNode->nextNode = head;
     head = newNode;
  }
  else
  {  setPosition(p-1,current);
     newNode->nextNode = current->nextNode;
     current->nextNode = newNode;
  }
  count++;
}
// pre-condicao: Lista ja tenha sido criada e n�o est� vazia
// pos-condicao: A entrada da posi��o p � removida da Lista e retornada na vari�vel x; as entradas de todas as posi��es seguintes t�m suas posi��es decrementadas
void List::remove(long p, ListEntry &x)
{ ListPointer node, current;

  if (p < 1 || p > count)
  { cout << "Posicao invalida" << endl;
    abort();
  }
  if(p == 1)
  {  node = head;
     head = node->nextNode;
  }
  else
  {  setPosition(p-1,current);
     node = current->nextNode;
     current->nextNode = node->nextNode;
  }
  x = node->entry;
  delete node;
  count = count - 1;
}
// pre-condicao: Lista ja tenha sido criada e n�o est� vazia
// pos-condicao: A entrada da posi��o p da Lista � retornada na vari�vel x
void List::retrieve(long p, ListEntry &x)
{ ListPointer current;

  setPosition(p,current);
  x = current->entry;
}
//pr�-condi��o:Lista j� tenha sido criada 
//p�s-condi��o:Retorna a posi��o pda Lista em que x foi encontrado; caso exista mais de um xna Lista, retorna o primeiro encontrado; retorna zero caso x n�o perten�a � Lista
long List::search(ListEntry x)
{ long p=1;
  ListPointer q=head;

  while (q != NULL && q->entry != x)
  {  q = q->nextNode;
     p++;
  }
  return (q == NULL ? 0 : p);
}
// pre-condicao: Lista ja tenha sido criada
// pos-condicao: Transforma conteudo em uma string separada por virgula
string List::toString()
{ ListPointer q=head;
  string s;
  stringstream ss;

  while (q != NULL)
  {  ss << q->entry << ",";
     q = q->nextNode;
  }
  s = ss.str();
  return "[" + s.substr(0,s.length()-1) + "]";
}
// pre-condicao: Lista ja tenha sido criada
// pos-condicao: Transforma os endere�os em uma string separada por virgula
string List::toStringAddr()
{ ListPointer q=head;
  string s;
  stringstream ss;

  while (q != NULL)
  {  ss << q << ",";
     q = q->nextNode;
  }
  s = ss.str();
  return "[" + s.substr(0,s.length()-1) + "]";
}
//pre-condi��o: Lista tenha sido criada, n�o esteja cheia
//pos-condi��o: Retorna a variavel current com a posi��o de p equivalente na lista
void List::setPosition(long p, ListPointer &current)
{ long i;

  if (p < 1 || p > count+1)
  { cout << "Posicao invalida" << endl;
    abort();
  }
  current = head;
  for(i=2; i<=p; i++)
      current = current->nextNode;
}
//pre-condicao: Lista j� tenha sido criada
//pos-condicao: retorna o endere�o do valor inserido
long long List::getAddr(ListEntry x)
{ ListPointer current=NULL;
  long p = search(x);
  if(p != 0)
    setPosition(p, current);
  return (long long)current;
}
// pre-condicao: Lista j� tenha sido criada
// pos-condi��o: Os elementos escolhidos da lista s�o trocados
bool List::swap(ListEntry a, ListEntry b)
{ 
	if(empty() || count <= 1 || a == b) //Caso a lista esteja vazia, o tamanho for igual ou menor que 1 ou a ser igual a b retorne falso
		return false;
	else{
			ListPointer NodeA, NodeB,anteriorA, anteriorB, auxiliar; //Declara��o dos ponteiros que ser�o necess�rios	
			NodeA = head;
			NodeB = head;	
			for(int i = 0; i < count; i++){							//Percorra toda a lista 
				if(NodeA->entry != a){								//Enquanto o valor de NodeA for diferente do valor de a
					anteriorA = NodeA;								//Ponteiro que marca o anterior ao NodeA vira o NodeA
					NodeA = NodeA->nextNode;						//NodeA passa a ser o pr�ximo Node
				}
				if(NodeB->entry != b){								//Enquanto o valor de NodeB for diferente do valor de b
					anteriorB = NodeB;								//Ponteiro que marca o anterior ao NodeB vira o NodeB
					NodeB = NodeB->nextNode;						//NodeB passa a ser o pr�ximo Node
				}
			}
			
			if(NodeB == NULL || NodeA == NULL)						//Se NodeA ou NodeB forem vazios retorne falso
				return false;
			
			else if(NodeA == head){									//Se NodeA for igual ao topo
				head = NodeB;										//NodeB passar� a ser igual ao topo
				anteriorB->nextNode = NodeA;						//O Node pr�ximo Node do anterior a B passa a ser o NodeA
			}
			else if(NodeB == head){									//Se NodeB for igual ao topo
				head = NodeA;										//NodeA passar� a ser igual ao topo
				anteriorA->nextNode = NodeB;						//O Node pr�ximo Node do anterior a A passa a ser o NodeB
			}
			else{													//Sen�o:
				anteriorA->nextNode = NodeB; 						//O proximo Node do anterior a A passa a ser o NodeB
				anteriorB->nextNode = NodeA;						//E o pr�ximo Node do anterior a B passa a ser o NodeA
			}
				
			auxiliar = NodeA->nextNode;								//Armazena o valor do pr�ximo Node de NodeA em um ponteiro auxiliar
			NodeA->nextNode = NodeB->nextNode;						//Proximo Node de NodeA passa a ser o pr�ximo Node de NodeB
			NodeB->nextNode = auxiliar;								//Pr�ximo Node de NodeB passa a ser o valor do ponteiro auxiliar
			return true;											//Retorne verdadeiro
		}
			
		//}
} 
	

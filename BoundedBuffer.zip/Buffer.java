/*
 * Buffer.java
 *
 */

public interface Buffer {
    public void insert(Object item);
    public Object remove();
}

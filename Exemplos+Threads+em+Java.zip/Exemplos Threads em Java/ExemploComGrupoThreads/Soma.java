/**
 *
 * @author Clever R. G. de Farias
 */
public class Soma {
    
    private int soma;
    
    /** Creates a new instance of Soma */
    public Soma() {
        soma = 0;
    }
    
    public int getSoma() {
       return soma;
    }

    public void setSoma(int nro) {
        soma = nro;
    }
}
